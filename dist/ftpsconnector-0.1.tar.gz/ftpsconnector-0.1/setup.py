from setuptools import setup

setup(name='ftpsconnector',
      version='0.1',
      description='Initial connector code for pensieve',
      url='http://github.com/bc/ftpsconnector',
      author='Brian Cohn',
      author_email='brian.cohn@usc.edu',
      license='MIT',
      packages=['ftpsconnector'],
      zip_safe=False)
